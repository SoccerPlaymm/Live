package com.soccer.play;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import cn.jzvd.*;
import com.bumptech.glide.Glide;
import com.gdacciaro.iOSDialog.*;
import com.lxj.xpopup.*;
import com.startapp.sdk.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.startapp.sdk.ads.banner.*;
import com.startapp.sdk.adsbase.*;
import com.startapp.sdk.adsbase.adlisteners.*;

public class NewsRedActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout main_bg;
	private LinearLayout top;
	private LinearLayout bg;
	private ImageView image_back;
	private LinearLayout icon_bg;
	private ImageView icon_image;
	private ScrollView vscroll2;
	private LinearLayout scroll_bg;
	private LinearLayout vp_vg;
	private LinearLayout text_bg;
	private LinearLayout bn1;
	private LinearLayout bn2;
	private LinearLayout linearcolor;
	private ViewPager slide;
	private TextView news_title_bg;
	private LinearLayout news_data_bg;
	private TextView news_bg;
	private TextView textview2;
	private LinearLayout linear1;
	private TextView textview3;
	
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.news_red);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main_bg = findViewById(R.id.main_bg);
		top = findViewById(R.id.top);
		bg = findViewById(R.id.bg);
		image_back = findViewById(R.id.image_back);
		icon_bg = findViewById(R.id.icon_bg);
		icon_image = findViewById(R.id.icon_image);
		vscroll2 = findViewById(R.id.vscroll2);
		scroll_bg = findViewById(R.id.scroll_bg);
		vp_vg = findViewById(R.id.vp_vg);
		text_bg = findViewById(R.id.text_bg);
		bn1 = findViewById(R.id.bn1);
		bn2 = findViewById(R.id.bn2);
		linearcolor = findViewById(R.id.linearcolor);
		slide = findViewById(R.id.slide);
		news_title_bg = findViewById(R.id.news_title_bg);
		news_data_bg = findViewById(R.id.news_data_bg);
		news_bg = findViewById(R.id.news_bg);
		textview2 = findViewById(R.id.textview2);
		linear1 = findViewById(R.id.linear1);
		textview3 = findViewById(R.id.textview3);
		
		image_back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final StartAppAd int1 = new StartAppAd(NewsRedActivity.this);
				int1.showAd(new AdDisplayListener() {
						       @Override
						    public void adHidden(Ad ad) {
						
						finish();
					}
						@Override
						    public void adDisplayed(Ad ad) {
								SketchwareUtil.showMessage(getApplicationContext(), "ကြေငြာ ကြည့်နေသည်");
								    }
						@Override
						    public void adClicked(Ad ad) {
								SketchwareUtil.showMessage(getApplicationContext(), "‌ကြေငြာ အားနှိပ်လိုက်သည်");
								    }
						@Override
						    public void adNotDisplayed(Ad ad) {
								SketchwareUtil.showMessage(getApplicationContext(), "ကြေငြာ မရရှိပါ");
								    }
				});
			}
		});
	}
	
	private void initializeLogic() {
		Window w = NewsRedActivity.this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor("#FFFFFF")); linearcolor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		_RoundCorner(30, 30, 0, 0, "#115c9f", text_bg);
		final float scaleFactor = 0.95f; slide.setPageMargin(-35); slide.setOffscreenPageLimit(2); slide.setPageTransformer(false, new ViewPager.PageTransformer() { @Override public void transformPage(@NonNull View page, float position) { page.setScaleY((1 - Math.abs(position) * (1 - scaleFactor))); page.setScaleX(scaleFactor + Math.abs(position) * (1 - scaleFactor)); } });
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										slide.setCurrentItem((int)1);
									}
								});
							}
						};
						_timer.schedule(t, (int)(2000));
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										slide.setCurrentItem((int)2);
									}
								});
							}
						};
						_timer.schedule(t, (int)(4000));
						t = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										slide.setCurrentItem((int)0);
									}
								});
							}
						};
						_timer.schedule(t, (int)(6000));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(6000));
		news_title_bg.setText(getIntent().getStringExtra("Title"));
		textview2.setText("UploadTime".concat(" : ".concat(getIntent().getStringExtra("Date"))));
		textview3.setText("NewsBy".concat(" : ".concat(getIntent().getStringExtra("By"))));
		news_bg.setText(getIntent().getStringExtra("News"));
		StartAppSDK.init(NewsRedActivity.this, "207297507", true);
		Banner banner1 = new Banner(NewsRedActivity.this);
		banner1.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		bn1.addView(banner1);
		Banner banner2 = new Banner(NewsRedActivity.this);
		banner2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		bn2.addView(banner2);
		final StartAppAd int1 = new StartAppAd(NewsRedActivity.this);
		int1.showAd(new AdDisplayListener() {
				       @Override
				    public void adHidden(Ad ad) {
				
			}
				@Override
				    public void adDisplayed(Ad ad) {
						SketchwareUtil.showMessage(getApplicationContext(), "ad show");
						    }
				@Override
				    public void adClicked(Ad ad) {
						SketchwareUtil.showMessage(getApplicationContext(), "‌click");
						    }
				@Override
				    public void adNotDisplayed(Ad ad) {
						SketchwareUtil.showMessage(getApplicationContext(), "ad error");
						    }
		});
		StartAppAd.disableSplash();
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", getIntent().getStringExtra("Image1"));
			list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", getIntent().getStringExtra("Image2"));
			list.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("image", getIntent().getStringExtra("Image3"));
			list.add(_item);
		}
		
		slide.setAdapter(new SlideAdapter(list));
		slide.setCurrentItem((int)0);
	}
	
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _RoundCorner(final double _one, final double _two, final double _three, final double _four, final String _color, final View _view) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		android.graphics.drawable.GradientDrawable c = new android.graphics.drawable.GradientDrawable();
		c.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		c.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		c.setColor(Color.parseColor(_color));
		_view.setBackground(c);
	}
	
	public class SlideAdapter extends PagerAdapter {
		
		Context _context;
		ArrayList<HashMap<String, Object>> _data;
		
		public SlideAdapter(Context _ctx, ArrayList<HashMap<String, Object>> _arr) {
			_context = _ctx;
			_data = _arr;
		}
		
		public SlideAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_context = getApplicationContext();
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public boolean isViewFromObject(View _view, Object _object) {
			return _view == _object;
		}
		
		@Override
		public void destroyItem(ViewGroup _container, int _position, Object _object) {
			_container.removeView((View) _object);
		}
		
		@Override
		public int getItemPosition(Object _object) {
			return super.getItemPosition(_object);
		}
		
		@Override
		public CharSequence getPageTitle(int pos) {
			// Use the Activity Event (onTabLayoutNewTabAdded) in order to use this method
			return "page " + String.valueOf(pos);
		}
		
		@Override
		public Object instantiateItem(ViewGroup _container,  final int _position) {
			View _view = LayoutInflater.from(_context).inflate(R.layout.news_slide, _container, false);
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(list.get((int)_position).get("image").toString())).into(imageview1);
			
			_container.addView(_view);
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}