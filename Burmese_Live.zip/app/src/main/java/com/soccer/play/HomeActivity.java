package com.soccer.play;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import cn.jzvd.*;
import com.bumptech.glide.Glide;
import com.gdacciaro.iOSDialog.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.lxj.xpopup.*;
import com.startapp.sdk.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.startapp.sdk.ads.banner.*;
import com.startapp.sdk.adsbase.*;
import com.startapp.sdk.adsbase.adlisteners.*;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double scroll = 0;
	private double let1 = 0;
	private double n1 = 0;
	private String sea1 = "";
	private String call = "";
	private double let2 = 0;
	private double n2 = 0;
	private String sea2 = "";
	private double let3 = 0;
	private double n3 = 0;
	private String sea3 = "";
	private double n = 0;
	private double let = 0;
	private String sea = "";
	private double current_time = 0;
	private double tm_difference = 0;
	private double current = 0;
	private double difference = 0;
	private double current1 = 0;
	private double difference1 = 0;
	private double current2 = 0;
	private double difference2 = 0;
	private  final static int ID_FIRST = 1;
	private  final static int ID_SECOND = 2;
	private  final static int ID_THIRD = 3;
	private  final static int ID_FOURTH = 4;
	private HashMap<String, Object> mappp = new HashMap<>();
	private  final static int ID_FIVE = 5;
	
	private ArrayList<HashMap<String, Object>> slide_list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> home_live = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> home_news = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> today = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> home_high = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> high = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> news = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> live = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> livet = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tvchc = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tvchmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> hott = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> muw = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> chels = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> arsena = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> mancit = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> liverp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> tottha = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> othe = new ArrayList<>();
	
	private LinearLayout top;
	private LinearLayout linear1;
	private FrameLayout bg;
	private LinearLayout icon_bg;
	private ImageView imageview9;
	private ImageView icon_image;
	private LinearLayout linearcolor;
	private ViewPager slide;
	private LinearLayout base;
	private LinearLayout trash;
	private LinearLayout layout_bg;
	private MeowBottomNavigation meow;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private LinearLayout layout3;
	private LinearLayout layout4;
	private LinearLayout layout5;
	private HorizontalScrollView hscroll1;
	private GridView manu;
	private GridView chel;
	private GridView ars;
	private GridView manc;
	private GridView liv;
	private GridView tott;
	private GridView other;
	private LinearLayout linear3;
	private LinearLayout mu;
	private LinearLayout ch;
	private LinearLayout ar;
	private LinearLayout mc;
	private LinearLayout lv;
	private LinearLayout tot;
	private LinearLayout oth;
	private ImageView imageview2;
	private TextView textview3;
	private ImageView imageview8;
	private TextView textview8;
	private ImageView imageview7;
	private TextView textview7;
	private ImageView imageview6;
	private TextView textview6;
	private ImageView imageview5;
	private TextView textview5;
	private ImageView imageview3;
	private TextView textview4;
	private ImageView imageview4;
	private TextView textview9;
	private ListView high_list;
	private LinearLayout linear2;
	private ListView today_list;
	private ListView hot;
	private LinearLayout All_bg;
	private LinearLayout hot_bg;
	private TextView textview1;
	private LinearLayout live_bar1;
	private TextView textview2;
	private LinearLayout live_bar2;
	private ListView all_news_list;
	private GridView gridview1;
	
	private TimerTask t;
	private ObjectAnimator anim = new ObjectAnimator();
	private Intent go = new Intent();
	private Calendar cal = Calendar.getInstance();
	private SharedPreferences DiShow;
	private AlertDialog.Builder di;
	private RequestNetwork in;
	private RequestNetwork.RequestListener _in_request_listener;
	private Calendar clnd = Calendar.getInstance();
	private SharedPreferences Userr;
	private SharedPreferences i;
	private RequestNetwork tvch;
	private RequestNetwork.RequestListener _tvch_request_listener;
	private RequestNetwork livee;
	private RequestNetwork.RequestListener _livee_request_listener;
	private RequestNetwork hihg;
	private RequestNetwork.RequestListener _hihg_request_listener;
	private RequestNetwork newss;
	private RequestNetwork.RequestListener _newss_request_listener;
	private RequestNetwork slidee;
	private RequestNetwork.RequestListener _slidee_request_listener;
	private TimerTask k;
	private RequestNetwork muu;
	private RequestNetwork.RequestListener _muu_request_listener;
	private Intent ahskoqiwhvbaha;
	// wv;
	private RequestNetwork che;
	private RequestNetwork.RequestListener _che_request_listener;
	private RequestNetwork arse;
	private RequestNetwork.RequestListener _arse_request_listener;
	private RequestNetwork mancity;
	private RequestNetwork.RequestListener _mancity_request_listener;
	private RequestNetwork liver;
	private RequestNetwork.RequestListener _liver_request_listener;
	private RequestNetwork totth;
	private RequestNetwork.RequestListener _totth_request_listener;
	private RequestNetwork otherr;
	private RequestNetwork.RequestListener _otherr_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		top = findViewById(R.id.top);
		linear1 = findViewById(R.id.linear1);
		bg = findViewById(R.id.bg);
		icon_bg = findViewById(R.id.icon_bg);
		imageview9 = findViewById(R.id.imageview9);
		icon_image = findViewById(R.id.icon_image);
		linearcolor = findViewById(R.id.linearcolor);
		slide = findViewById(R.id.slide);
		base = findViewById(R.id.base);
		trash = findViewById(R.id.trash);
		layout_bg = findViewById(R.id.layout_bg);
		meow = findViewById(R.id.meow);
		layout1 = findViewById(R.id.layout1);
		layout2 = findViewById(R.id.layout2);
		layout3 = findViewById(R.id.layout3);
		layout4 = findViewById(R.id.layout4);
		layout5 = findViewById(R.id.layout5);
		hscroll1 = findViewById(R.id.hscroll1);
		manu = findViewById(R.id.manu);
		chel = findViewById(R.id.chel);
		ars = findViewById(R.id.ars);
		manc = findViewById(R.id.manc);
		liv = findViewById(R.id.liv);
		tott = findViewById(R.id.tott);
		other = findViewById(R.id.other);
		linear3 = findViewById(R.id.linear3);
		mu = findViewById(R.id.mu);
		ch = findViewById(R.id.ch);
		ar = findViewById(R.id.ar);
		mc = findViewById(R.id.mc);
		lv = findViewById(R.id.lv);
		tot = findViewById(R.id.tot);
		oth = findViewById(R.id.oth);
		imageview2 = findViewById(R.id.imageview2);
		textview3 = findViewById(R.id.textview3);
		imageview8 = findViewById(R.id.imageview8);
		textview8 = findViewById(R.id.textview8);
		imageview7 = findViewById(R.id.imageview7);
		textview7 = findViewById(R.id.textview7);
		imageview6 = findViewById(R.id.imageview6);
		textview6 = findViewById(R.id.textview6);
		imageview5 = findViewById(R.id.imageview5);
		textview5 = findViewById(R.id.textview5);
		imageview3 = findViewById(R.id.imageview3);
		textview4 = findViewById(R.id.textview4);
		imageview4 = findViewById(R.id.imageview4);
		textview9 = findViewById(R.id.textview9);
		high_list = findViewById(R.id.high_list);
		linear2 = findViewById(R.id.linear2);
		today_list = findViewById(R.id.today_list);
		hot = findViewById(R.id.hot);
		All_bg = findViewById(R.id.All_bg);
		hot_bg = findViewById(R.id.hot_bg);
		textview1 = findViewById(R.id.textview1);
		live_bar1 = findViewById(R.id.live_bar1);
		textview2 = findViewById(R.id.textview2);
		live_bar2 = findViewById(R.id.live_bar2);
		all_news_list = findViewById(R.id.all_news_list);
		gridview1 = findViewById(R.id.gridview1);
		DiShow = getSharedPreferences("DiShow", Activity.MODE_PRIVATE);
		di = new AlertDialog.Builder(this);
		in = new RequestNetwork(this);
		Userr = getSharedPreferences("Userr", Activity.MODE_PRIVATE);
		i = getSharedPreferences("i", Activity.MODE_PRIVATE);
		tvch = new RequestNetwork(this);
		livee = new RequestNetwork(this);
		hihg = new RequestNetwork(this);
		newss = new RequestNetwork(this);
		slidee = new RequestNetwork(this);
		muu = new RequestNetwork(this);
		che = new RequestNetwork(this);
		arse = new RequestNetwork(this);
		mancity = new RequestNetwork(this);
		liver = new RequestNetwork(this);
		totth = new RequestNetwork(this);
		otherr = new RequestNetwork(this);
		
		imageview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final com.google.android.material.bottomsheet.BottomSheetDialog di = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
				View inflate = getLayoutInflater().inflate(R.layout.info, null);
				di.setContentView(inflate);
				di.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				LinearLayout l2 = (LinearLayout)
				inflate.findViewById(R.id.l2);
				LinearLayout l1 = (LinearLayout)
				inflate.findViewById(R.id.l1);
				LinearLayout l3 = (LinearLayout)
				inflate.findViewById(R.id.l3);
				LinearLayout l4 = (LinearLayout)
				inflate.findViewById(R.id.l4);
				ImageView i1 = (ImageView)
				inflate.findViewById(R.id.i1);
				ImageView i2 = (ImageView)
				inflate.findViewById(R.id.i2);
				ImageView i3 = (ImageView)
				inflate.findViewById(R.id.i3);
				TextView t1 = (TextView)
				inflate.findViewById(R.id.t1);
				TextView t2 = (TextView)
				inflate.findViewById(R.id.t2);
				l2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFFFFF));
				t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
				t2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp_2.ttf"), 1);
				di.show();
			}
		});
		
		mu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
				manu.setVisibility(View.VISIBLE);
				chel.setVisibility(View.GONE);
				ars.setVisibility(View.GONE);
				manc.setVisibility(View.GONE);
				liv.setVisibility(View.GONE);
				tott.setVisibility(View.GONE);
				other.setVisibility(View.GONE);
			}
		});
		
		ch.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFD9030E, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
				manu.setVisibility(View.GONE);
				chel.setVisibility(View.VISIBLE);
				ars.setVisibility(View.GONE);
				manc.setVisibility(View.GONE);
				liv.setVisibility(View.GONE);
				tott.setVisibility(View.GONE);
				other.setVisibility(View.GONE);
			}
		});
		
		ar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFD9030E, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
				manu.setVisibility(View.GONE);
				chel.setVisibility(View.GONE);
				ars.setVisibility(View.VISIBLE);
				manc.setVisibility(View.GONE);
				liv.setVisibility(View.GONE);
				tott.setVisibility(View.GONE);
				other.setVisibility(View.GONE);
			}
		});
		
		mc.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFD9030E, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
				manu.setVisibility(View.GONE);
				chel.setVisibility(View.GONE);
				ars.setVisibility(View.GONE);
				manc.setVisibility(View.VISIBLE);
				liv.setVisibility(View.GONE);
				tott.setVisibility(View.GONE);
				other.setVisibility(View.GONE);
			}
		});
		
		lv.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFD9030E, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
				manu.setVisibility(View.GONE);
				chel.setVisibility(View.GONE);
				ars.setVisibility(View.GONE);
				manc.setVisibility(View.GONE);
				liv.setVisibility(View.VISIBLE);
				tott.setVisibility(View.GONE);
				other.setVisibility(View.GONE);
			}
		});
		
		tot.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFD9030E, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
				manu.setVisibility(View.GONE);
				chel.setVisibility(View.GONE);
				ars.setVisibility(View.GONE);
				manc.setVisibility(View.GONE);
				liv.setVisibility(View.GONE);
				tott.setVisibility(View.VISIBLE);
				other.setVisibility(View.GONE);
			}
		});
		
		oth.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFD9030E, 0xFF115C9F));
				ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
				ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
				mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
				lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
				tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
				oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
				manu.setVisibility(View.GONE);
				chel.setVisibility(View.GONE);
				ars.setVisibility(View.GONE);
				manc.setVisibility(View.GONE);
				liv.setVisibility(View.GONE);
				tott.setVisibility(View.GONE);
				other.setVisibility(View.VISIBLE);
			}
		});
		
		All_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				live_bar1.setVisibility(View.VISIBLE);
				live_bar2.setVisibility(View.GONE);
				today_list.setVisibility(View.VISIBLE);
				hot.setVisibility(View.GONE);
			}
		});
		
		hot_bg.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				live_bar1.setVisibility(View.GONE);
				live_bar2.setVisibility(View.VISIBLE);
				today_list.setVisibility(View.GONE);
				hot.setVisibility(View.VISIBLE);
			}
		});
		
		_in_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_tvch_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				tvchmap = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				gridview1.setAdapter(new Gridview1Adapter(tvchmap));
				gridview1.setColumnWidth((int)120);
				gridview1.setNumColumns((int)3);
				gridview1.setVerticalSpacing((int)20);
				gridview1.setHorizontalSpacing((int)20);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_livee_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				livet = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				hott = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				today_list.setAdapter(new Today_listAdapter(livet));
				((BaseAdapter)today_list.getAdapter()).notifyDataSetChanged();
				let = hott.size();
				n = let - 1;
				for(int _repeat63 = 0; _repeat63 < (int)(let); _repeat63++) {
					sea = hott.get((int)n).get("Hot").toString();
					if (!("Hot".length() > sea.length()) && sea.toLowerCase().contains("Hot".toLowerCase())) {
						
					}
					else {
						hott.remove((int)(n));
					}
					n--;
				}
				hot.setAdapter(new HotAdapter(hott));
				((BaseAdapter)hot.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_hihg_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				high = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				high_list.setAdapter(new High_listAdapter(high));
				((BaseAdapter)high_list.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_newss_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				news = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				all_news_list.setAdapter(new All_news_listAdapter(news));
				((BaseAdapter)all_news_list.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_slidee_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				slide_list = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				slide.setAdapter(new SlideAdapter(slide_list));
				slide.setCurrentItem((int)0);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_muu_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				muw = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				manu.setAdapter(new ManuAdapter(muw));
				manu.setVerticalSpacing((int)10);
				manu.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				manu.setNumColumns((int)2);
				manu.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_che_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				chels = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				chel.setAdapter(new ChelAdapter(chels));
				chel.setVerticalSpacing((int)10);
				chel.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				chel.setNumColumns((int)2);
				chel.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_arse_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				arsena = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				ars.setAdapter(new ArsAdapter(arsena));
				ars.setVerticalSpacing((int)10);
				ars.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				ars.setNumColumns((int)2);
				ars.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_mancity_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				mancit = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				manc.setAdapter(new MancAdapter(mancit));
				manc.setVerticalSpacing((int)10);
				manc.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				manc.setNumColumns((int)2);
				manc.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_liver_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				liverp = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				liv.setAdapter(new LivAdapter(liverp));
				liv.setVerticalSpacing((int)10);
				liv.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				liv.setNumColumns((int)2);
				liv.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_totth_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				tottha = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				tott.setAdapter(new TottAdapter(tottha));
				tott.setVerticalSpacing((int)10);
				tott.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				tott.setNumColumns((int)2);
				tott.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_otherr_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				othe = new Gson().fromJson(_response, new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				other.setAdapter(new OtherAdapter(othe));
				other.setVerticalSpacing((int)10);
				other.setColumnWidth((int)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2) - 8);
				other.setNumColumns((int)2);
				other.setStretchMode(GridView.STRETCH_SPACING);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		Window w = HomeActivity.this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor("#FFFFFF")); linearcolor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		cal = Calendar.getInstance();
		call = new SimpleDateFormat("d/M/yyyy").format(cal.getTime());
		_viewPager();
		_ICC(imageview9, "#115c9f", "#115c9f");
		viewPager.setCurrentItem(0);
		_ui();
		meow.add(new MeowBottomNavigation.Model(ID_FIRST, R.drawable.icons8));
		meow.add(new MeowBottomNavigation.Model(ID_SECOND, R.drawable.icons_2));
		meow.add(new MeowBottomNavigation.Model(ID_THIRD, R.drawable.icons8_2));
		meow.add(new MeowBottomNavigation.Model(ID_FOURTH, R.drawable.icons8_1));
		meow.add(new MeowBottomNavigation.Model(ID_FIVE, R.drawable.icons8_tv));
		meow.setOnShowListener(new MeowBottomNavigation.ShowListener() { @Override public void onShowItem(MeowBottomNavigation.Model item) {String name; switch (item.getId()) {
								case ID_FIRST:
								_first();
								break;
								case ID_SECOND:
								_second();
								break;
								case ID_THIRD:
								_third();
								break;
								case ID_FOURTH:
								_fourth();
								break;
					    case ID_FIVE:
								_five();
								break;
						} }});
		meow.show(ID_THIRD, true);
		meow.setOnClickMenuListener(new MeowBottomNavigation.ClickListener() { @Override public void onClickItem(MeowBottomNavigation.Model item)
			{switch (item.getId()) {
					case ID_FIRST:
					_first();
					break;
					case ID_SECOND:
					_second();
					break;
					case ID_THIRD:
					_third();
					break;
					case ID_FOURTH:
					_fourth();
					break;
					case ID_FIVE:
					_five();
					break;
				}
			}});
		meow.setOnReselectListener(new MeowBottomNavigation.ReselectListener() { @Override public void onReselectItem(MeowBottomNavigation.Model item) {
				 
				 } });
		meow.setDefaultIconColor(0xFF115C9F);
		meow.setSelectedIconColor(0xFF115C9F);
		meow.setCircleColor(0xFFFFFFFF);
		meow.setBackgroundBottomColor(0xFFFFFFFF);
		FrameLayout rl = new FrameLayout(this); FrameLayout.LayoutParams lparams = new FrameLayout.LayoutParams( RelativeLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT); rl.setLayoutParams(lparams); bg.removeAllViews(); rl.addView(base); rl.addView(meow); bg.addView(rl);
		final float scaleFactor = 0.95f; slide.setPageMargin(-15); slide.setOffscreenPageLimit(2); slide.setPageTransformer(false, new ViewPager.PageTransformer() { @Override public void transformPage(@NonNull View page, float position) { page.setScaleY((1 - Math.abs(position) * (1 - scaleFactor))); page.setScaleX(scaleFactor + Math.abs(position) * (1 - scaleFactor)); } });
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (slide.getCurrentItem() == (slide_list.size() - 1)) {
							slide.setCurrentItem((int)0);
						}
						else {
							slide.setCurrentItem((int)slide.getCurrentItem() + 1);
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(4000), (int)(4000));
		StartAppSDK.init(HomeActivity.this, "207297507", true);
		StartAppAd.disableSplash();
		live_bar1.setVisibility(View.VISIBLE);
		today_list.setVisibility(View.VISIBLE);
		hot.setVisibility(View.GONE);
		live_bar2.setVisibility(View.GONE);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		_RoundCorner(5, 5, 0, 0, "#115c9f", live_bar1);
		_RoundCorner(5, 5, 0, 0, "#115c9f", live_bar2);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
		mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF000000, 0xFF115C9F));
		ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF044693, 0xFF115C9F));
		ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFDA0007, 0xFF115C9F));
		mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF4679A9, 0xFF115C9F));
		lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFCF0027, 0xFF115C9F));
		tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFF001A57, 0xFF115C9F));
		oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)5, 0xFFC01B2B, 0xFF115C9F));
		in.startRequestNetwork(RequestNetworkController.GET, "http://www.google.com", "i", _in_request_listener);
		tvch.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Tvchannel/Channel.json", "c", _tvch_request_listener);
		livee.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Live/live.json", "l", _livee_request_listener);
		slidee.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/SoccerPlay/slide.json", "s", _slidee_request_listener);
		newss.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/SoccerPlay/News.json", "n", _newss_request_listener);
		hihg.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Highlight/highlight.json", "h", _hihg_request_listener);
		muu.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/ManchesterUnited.json", "mu", _muu_request_listener);
		che.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/Chelsea.json", "mu", _che_request_listener);
		arse.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/arsenal.json", "mu", _arse_request_listener);
		mancity.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/ManchesterCity.json", "mu", _mancity_request_listener);
		liver.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/Liverpool.json", "mu", _liver_request_listener);
		totth.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/TottenhamHotspur.json", "mu", _totth_request_listener);
		otherr.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/Other.json", "mu", _otherr_request_listener);
	}
	
	@Override
	public void onBackPressed() {
		if (false) {
			
		}
		else {
			finishAffinity();
		}
	}
	
	public void _ICC(final ImageView _img, final String _c1, final String _c2) {
		_img.setImageTintList(new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed},{android.R.attr.state_pressed}},new int[]{Color.parseColor(_c1), Color.parseColor(_c2)}));
	}
	
	
	public void _RippleEffect(final String _color, final View _view) {
		android.content.res.ColorStateList clr = new android.content.res.ColorStateList(new int[][]{new int[]{}},new int[]{Color.parseColor(_color)});
		
		android.graphics.drawable.RippleDrawable ripdr = new android.graphics.drawable.RippleDrawable(clr, null, null);
		_view.setBackground(ripdr);
	}
	
	
	public void _RoundCorner(final double _one, final double _two, final double _three, final double _four, final String _color, final View _view) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		android.graphics.drawable.GradientDrawable c = new android.graphics.drawable.GradientDrawable();
		c.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		c.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		c.setColor(Color.parseColor(_color));
		_view.setBackground(c);
	}
	
	
	public void _Viewhight(final View _view, final double _num1) {
		_view.getLayoutParams().height=(int)(_num1);
	}
	
	
	public void _ui() {
		
	}
	
	
	public void _roundImageView(final ImageView _imageview, final double _round) {
		//Made by Ilyasse Salama
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)_imageview.getDrawable()).getBitmap();
		
		_imageview.setImageBitmap(getRoundedCornerBitmap(bm, ((int)_round)));
		
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint); 
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN)); 
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}
	
	
	public void _click_effect(final View _view, final String _c) {
		_view.setBackground(Drawables.getSelectableDrawableFor(Color.parseColor(_c)));
		_view.setClickable(true);
		
	}
	
	public static class Drawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[8];
			        Arrays.fill(outerRadii, 0);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
			    }
	}
	public static class CircleDrawables {
		    public static android.graphics.drawable.Drawable getSelectableDrawableFor(int color) {
			        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
				            android.graphics.drawable.StateListDrawable stateListDrawable = new android.graphics.drawable.StateListDrawable();
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_pressed},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{android.R.attr.state_focused},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            stateListDrawable.addState(
				                new int[]{},
				                new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"))
				            );
				            return stateListDrawable;
				        } else {
				            android.content.res.ColorStateList pressedColor = android.content.res.ColorStateList.valueOf(color);
				            android.graphics.drawable.ColorDrawable defaultColor = new android.graphics.drawable.ColorDrawable(Color.parseColor("#00ffffff"));
				            
				android.graphics.drawable.Drawable rippleColor = getRippleColor(color);
				            return new android.graphics.drawable.RippleDrawable(
				                pressedColor,
				                defaultColor,
				                rippleColor
				            );
				        }
			    }
		
		    private static android.graphics.drawable.Drawable getRippleColor(int color) {
			        float[] outerRadii = new float[180];
			        Arrays.fill(outerRadii, 80);
			        android.graphics.drawable.shapes.RoundRectShape r = new android.graphics.drawable.shapes.RoundRectShape(outerRadii, null, null);
			        
			android.graphics.drawable.ShapeDrawable shapeDrawable = new 
			android.graphics.drawable.ShapeDrawable(r);
			        shapeDrawable.getPaint().setColor(color);
			        return shapeDrawable;
			    }
		 
		    private static int lightenOrDarken(int color, double fraction) {
			        if (canLighten(color, fraction)) {
				            return lighten(color, fraction);
				        } else {
				            return darken(color, fraction);
				        }
			    }
		 
		    private static int lighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = lightenColor(red, fraction);
			        green = lightenColor(green, fraction);
			        blue = lightenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static int darken(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        red = darkenColor(red, fraction);
			        green = darkenColor(green, fraction);
			        blue = darkenColor(blue, fraction);
			        int alpha = Color.alpha(color);
			 
			        return Color.argb(alpha, red, green, blue);
			    }
		 
		    private static boolean canLighten(int color, double fraction) {
			        int red = Color.red(color);
			        int green = Color.green(color);
			        int blue = Color.blue(color);
			        return canLightenComponent(red, fraction)
			            && canLightenComponent(green, fraction)
			            && canLightenComponent(blue, fraction);
			    }
		 
		    private static boolean canLightenComponent(int colorComponent, double fraction) {
			        int red = Color.red(colorComponent);
			        int green = Color.green(colorComponent);
			        int blue = Color.blue(colorComponent);
			        return red + (red * fraction) < 255
			            && green + (green * fraction) < 255
			            && blue + (blue * fraction) < 255;
			    }
		 
		    private static int darkenColor(int color, double fraction) {
			        return (int) Math.max(color - (color * fraction), 0);
			    }
		 
		    private static int lightenColor(int color, double fraction) {
			        return (int) Math.min(color + (color * fraction), 255);
		}
	}
	
	public void drawableclass() {
	}
	
	
	public void _viewPager() {
		viewPager = new androidx.viewpager.widget.ViewPager(this);
		
		viewPager.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		MyPagerAdapter adapter = new MyPagerAdapter();
		viewPager.setAdapter(adapter);
		viewPager.setCurrentItem(0);
		base.addView(viewPager);
		
		viewPager.addOnPageChangeListener(new androidx.viewpager.widget.ViewPager.OnPageChangeListener() {
			public void onPageSelected(int position) {
				
				if (viewPager.getCurrentItem() == 0) {
					meow.show(ID_FIRST, true);
					mu.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFF000000, 0xFF115C9F));
					ch.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFF044693, 0xFF115C9F));
					ar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFFDA0007, 0xFF115C9F));
					mc.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFF4679A9, 0xFF115C9F));
					lv.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFFCF0027, 0xFF115C9F));
					tot.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFF001A57, 0xFF115C9F));
					oth.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)3, 0xFFC01B2B, 0xFF115C9F));
					manu.setVisibility(View.VISIBLE);
					chel.setVisibility(View.GONE);
					ars.setVisibility(View.GONE);
					manc.setVisibility(View.GONE);
					liv.setVisibility(View.GONE);
					tott.setVisibility(View.GONE);
					other.setVisibility(View.GONE);
					muu.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Wallpaper/ManchesterUnited.json", "wp", _muu_request_listener);
				}
				else {
					if (viewPager.getCurrentItem() == 1) {
						meow.show(ID_SECOND, true);
						hihg.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Highlight/highlight.json", "h", _hihg_request_listener);
					}
					else {
						if (viewPager.getCurrentItem() == 2) {
							meow.show(ID_THIRD, true);
							live_bar1.setVisibility(View.VISIBLE);
							live_bar2.setVisibility(View.GONE);
							today_list.setVisibility(View.VISIBLE);
							hot.setVisibility(View.GONE);
							livee.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Live/live.json", "l", _livee_request_listener);
						}
						else {
							if (viewPager.getCurrentItem() == 3) {
								meow.show(ID_FOURTH, true);
								newss.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/SoccerPlay/News.json", "n", _newss_request_listener);
							}
							else {
								if (viewPager.getCurrentItem() == 4) {
									meow.show(ID_FIVE, true);
									tvch.startRequestNetwork(RequestNetworkController.GET, "https://soccerplaymm.github.io/Tvchannel/Channel.json", "c", _tvch_request_listener);
								}
							}
						}
					}
				}
			}
			@Override public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
				
			}
			@Override public void onPageScrollStateChanged(int state) {
				
			}
		});
		
		
		
		tabLayout = new com.google.android.material.tabs.TabLayout(this);
		tabLayout.setTabGravity(tabLayout.GRAVITY_FILL);
	}
	
	private class MyPagerAdapter extends androidx.viewpager.widget.PagerAdapter {
		public int getCount() {
			return 5;
		}
		
		@Override public Object instantiateItem(ViewGroup collection, int position) {
			
			LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View v = inflater.inflate(R.layout.empty, null);
			
			LinearLayout container = (LinearLayout) v.findViewById(R.id.linear1);
			
			if (position == 0) {
				ViewGroup parent = (ViewGroup) layout1.getParent();
				if (parent != null) {
					parent.removeView(layout1);
				}container.addView(layout1);
				
			} else if (position == 1) {
				ViewGroup parent = (ViewGroup) layout2.getParent();
				if (parent != null) {
					parent.removeView(layout2);
				}
				container.addView(layout2);
				
			} else if (position == 2) {
				ViewGroup parent = (ViewGroup) layout3.getParent();
				if (parent != null) {
					parent.removeView(layout3);
				}
				container.addView(layout3);
				
			} else if (position == 3) {
				ViewGroup parent = (ViewGroup) layout4.getParent();
				if (parent != null) {
					parent.removeView(layout4);
				}
				container.addView(layout4);
				
			} else if (position == 4) {
				ViewGroup parent = (ViewGroup) layout5.getParent();
				if (parent != null) {
					parent.removeView(layout5);
				}
				container.addView(layout5);
				
				
			}
			collection.addView(v, 0);
			return v;
		}
		@Override public void destroyItem(ViewGroup collection, int position, Object view) {
			collection.removeView((View) view);
			trash.addView((View) view);
		}
		@Override public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == ((View) arg1);}
		@Override public Parcelable saveState() {
			return null;
		}
	}
	androidx.viewpager.widget.ViewPager viewPager;
	com.google.android.material.tabs.TabLayout tabLayout;
	private void foo() {
	}
	
	
	public void _first() {
		viewPager.setCurrentItem(0);
	}
	
	
	public void _second() {
		viewPager.setCurrentItem(1);
	}
	
	
	public void _third() {
		viewPager.setCurrentItem(2);
	}
	
	
	public void _fourth() {
		viewPager.setCurrentItem(3);
	}
	
	
	public void _Organization() {
		
	}
	
	
	public void _five() {
		viewPager.setCurrentItem(4);
	}
	
	
	public void _DG_Download(final String _url, final String _path) {
		try{
			DownloadManager.Request request = new DownloadManager.Request(Uri.parse( _url)); 
			request.setMimeType(This.getContentResolver().getType(Uri.parse(_url))); 
			String cookies = CookieManager.getInstance().getCookie(_url); 
			request.addRequestHeader("cookie", cookies); 
			//request.addRequestHeader("User-Agent", tab.getSettings().getUserAgentString());
			request.setDescription("Downloading file..."); 
			request.setTitle(URLUtil.guessFileName(_url,"",""));
			request.allowScanningByMediaScanner(); 
			request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); 
			request.setDestinationInExternalPublicDir( _path.equals("")?Environment.DIRECTORY_DOWNLOADS:_path, URLUtil.guessFileName(_url,"","")); 
			DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE); dm.enqueue(request);
			Toast.makeText(getApplicationContext(), "Downloading File", Toast.LENGTH_LONG).show();
		}catch(Exception e){showMessage(e.toString());}
	}final Context This = this; void nothing(){
		
		
	}
	
	public class SlideAdapter extends PagerAdapter {
		
		Context _context;
		ArrayList<HashMap<String, Object>> _data;
		
		public SlideAdapter(Context _ctx, ArrayList<HashMap<String, Object>> _arr) {
			_context = _ctx;
			_data = _arr;
		}
		
		public SlideAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_context = getApplicationContext();
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public boolean isViewFromObject(View _view, Object _object) {
			return _view == _object;
		}
		
		@Override
		public void destroyItem(ViewGroup _container, int _position, Object _object) {
			_container.removeView((View) _object);
		}
		
		@Override
		public int getItemPosition(Object _object) {
			return super.getItemPosition(_object);
		}
		
		@Override
		public CharSequence getPageTitle(int pos) {
			// Use the Activity Event (onTabLayoutNewTabAdded) in order to use this method
			return "page " + String.valueOf(pos);
		}
		
		@Override
		public Object instantiateItem(ViewGroup _container,  final int _position) {
			View _view = LayoutInflater.from(_context).inflate(R.layout.slide, _container, false);
			
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			textview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF060814));
			Glide.with(getApplicationContext()).load(Uri.parse(slide_list.get((int)_position).get("SlideImage").toString())).into(imageview1);
			textview1.setText(slide_list.get((int)_position).get("SlideAbout").toString());
			
			_container.addView(_view);
			return _view;
		}
	}
	
	public class ManuAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ManuAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(muw.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(muw.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFFD9030E));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(muw.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class ChelAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ChelAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(chels.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(chels.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFF044693));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(chels.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class ArsAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ArsAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(arsena.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(arsena.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFFDA0007));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(arsena.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class MancAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public MancAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(mancit.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(mancit.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFF4679A9));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(mancit.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class LivAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public LivAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(liverp.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(liverp.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFFCF0027));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(liverp.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class TottAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public TottAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(tottha.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(tottha.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFF001A57));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(tottha.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class OtherAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public OtherAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.wallpaper, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			Glide.with(getApplicationContext()).load(Uri.parse(othe.get((int)_position).get("image").toString())).into(imageview1);
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final AlertDialog wv = new AlertDialog.Builder(HomeActivity.this).create();
					LayoutInflater wvLI = getLayoutInflater();
					View wvCV = (View) wvLI.inflate(R.layout.w_view, null);
					wv.setView(wvCV);
					final LinearLayout l1 = (LinearLayout)
					wvCV.findViewById(R.id.l1);
					final LinearLayout l2 = (LinearLayout)
					wvCV.findViewById(R.id.l2);
					final ImageView v_im = (ImageView)
					wvCV.findViewById(R.id.v_im);
					final LinearLayout d = (LinearLayout)
					wvCV.findViewById(R.id.d);
					Glide.with(getApplicationContext()).load(Uri.parse(othe.get((int)_position).get("image").toString())).into(v_im);
					d.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)3, 0xFFFFFFFF, 0xFFC01B2B));
					d.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							_DG_Download(othe.get((int)_position).get("image").toString(), "/download/");
							final StartAppAd int1 = new StartAppAd(HomeActivity.this);
							int1.showAd(new AdDisplayListener() {
									       @Override
									    public void adHidden(Ad ad) {
									
								}
									@Override
									    public void adDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad show");
											    }
									@Override
									    public void adClicked(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "‌click");
											    }
									@Override
									    public void adNotDisplayed(Ad ad) {
											SketchwareUtil.showMessage(getApplicationContext(), "ad error");
											    }
							});
						}
					});
					l1.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					l2.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							wv.dismiss();
						}
					});
					wv.setCancelable(true);
					wv.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					wv.show();
				}
			});
			
			return _view;
		}
	}
	
	public class High_listAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public High_listAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.highlights, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout top = _view.findViewById(R.id.top);
			final LinearLayout topbg = _view.findViewById(R.id.topbg);
			final LinearLayout bottom = _view.findViewById(R.id.bottom);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout live = _view.findViewById(R.id.live);
			final TextView league = _view.findViewById(R.id.league);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final ImageView homeimg = _view.findViewById(R.id.homeimg);
			final TextView homename = _view.findViewById(R.id.homename);
			final LinearLayout timebg = _view.findViewById(R.id.timebg);
			final TextView time = _view.findViewById(R.id.time);
			final LinearLayout linear14 = _view.findViewById(R.id.linear14);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final ImageView awayimg = _view.findViewById(R.id.awayimg);
			final TextView awayname = _view.findViewById(R.id.awayname);
			final LinearLayout linear16 = _view.findViewById(R.id.linear16);
			final ImageView iconnn = _view.findViewById(R.id.iconnn);
			final TextView date = _view.findViewById(R.id.date);
			
			live.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFF6A6F75));
			timebg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)3, 0xFFFFFFFF, Color.TRANSPARENT));
			_RoundCorner(20, 20, 0, 0, "#115c9f", top);
			_RoundCorner(0, 0, 20, 20, "#115c9f", bottom);
			league.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			homename.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			awayname.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			date.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			time.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			Glide.with(getApplicationContext()).load(Uri.parse(high.get((int)_position).get("HomeImage").toString())).into(homeimg);
			Glide.with(getApplicationContext()).load(Uri.parse(high.get((int)_position).get("AwayImage").toString())).into(awayimg);
			time.setText(high.get((int)_position).get("Time").toString());
			homename.setText(high.get((int)_position).get("HomeName").toString());
			awayname.setText(high.get((int)_position).get("AwayName").toString());
			league.setText(high.get((int)_position).get("LeagueName").toString());
			date.setText(high.get((int)_position).get("Date").toString());
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final com.google.android.material.bottomsheet.BottomSheetDialog di = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
					View inflate = getLayoutInflater().inflate(R.layout.qui, null);
					di.setContentView(inflate);
					di.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
					LinearLayout l = (LinearLayout)
					inflate.findViewById(R.id.l);
					LinearLayout l1 = (LinearLayout)
					inflate.findViewById(R.id.l1);
					LinearLayout bbg1 = (LinearLayout)
					inflate.findViewById(R.id.bbg1);
					LinearLayout bbg2 = (LinearLayout)
					inflate.findViewById(R.id.bbg2);
					LinearLayout bbg3 = (LinearLayout)
					inflate.findViewById(R.id.bbg3);
					LinearLayout b1 = (LinearLayout)
					inflate.findViewById(R.id.b1);
					LinearLayout b2 = (LinearLayout)
					inflate.findViewById(R.id.b2);
					LinearLayout b3 = (LinearLayout)
					inflate.findViewById(R.id.b3);
					LinearLayout b4 = (LinearLayout)
					inflate.findViewById(R.id.b4);
					LinearLayout b5 = (LinearLayout)
					inflate.findViewById(R.id.b5);
					LinearLayout b6 = (LinearLayout)
					inflate.findViewById(R.id.b6);
					TextView t1 = (TextView)
					inflate.findViewById(R.id.t1);
					TextView t2 = (TextView)
					inflate.findViewById(R.id.t2);
					TextView t3 = (TextView)
					inflate.findViewById(R.id.t3);
					TextView t4 = (TextView)
					inflate.findViewById(R.id.t4);
					TextView t5 = (TextView)
					inflate.findViewById(R.id.t5);
					TextView t6 = (TextView)
					inflate.findViewById(R.id.t6);
					TextView t7 = (TextView)
					inflate.findViewById(R.id.t7);
					TextView t8 = (TextView)
					inflate.findViewById(R.id.t8);
					b1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					_RoundCorner(50, 50, 50, 50, "#ffffff", l);
					t1.setText(high.get((int)_position).get("HomeName").toString().concat(" Vs ".concat(high.get((int)_position).get("AwayName").toString())));
					if ("0".equals(high.get((int)_position).get("Hd1Link").toString())) {
						b1.setVisibility(View.GONE);
					}
					else {
						b1.setVisibility(View.VISIBLE);
						t3.setText(high.get((int)_position).get("Hd1Name").toString());
					}
					if ("0".equals(high.get((int)_position).get("Hd2Link").toString())) {
						b2.setVisibility(View.GONE);
					}
					else {
						b2.setVisibility(View.VISIBLE);
						t4.setText(high.get((int)_position).get("Hd2Name").toString());
					}
					if ("0".equals(high.get((int)_position).get("Hd3Link").toString())) {
						b3.setVisibility(View.GONE);
					}
					else {
						b3.setVisibility(View.VISIBLE);
						t5.setText(high.get((int)_position).get("Hd3Name").toString());
					}
					if ("0".equals(high.get((int)_position).get("Hd4Link").toString())) {
						b4.setVisibility(View.GONE);
					}
					else {
						b4.setVisibility(View.VISIBLE);
						t6.setText(high.get((int)_position).get("Hd4Name").toString());
					}
					if ("0".equals(high.get((int)_position).get("Hd5Link").toString())) {
						b5.setVisibility(View.GONE);
					}
					else {
						b5.setVisibility(View.VISIBLE);
						t7.setText(high.get((int)_position).get("Hd5Name").toString());
					}
					if ("0".equals(high.get((int)_position).get("Hd6Link").toString())) {
						b6.setVisibility(View.GONE);
					}
					else {
						b6.setVisibility(View.VISIBLE);
						t8.setText(high.get((int)_position).get("Hd6Name").toString());
					}
					di.show();
					b1.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", high.get((int)_position).get("Hd1Link").toString());
							go.putExtra("MatchName", high.get((int)_position).get("HomeName").toString().concat(" X ".concat(high.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "high");
							startActivity(go);
									}
							});
					b2.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", high.get((int)_position).get("Hd2Link").toString());
							go.putExtra("MatchName", high.get((int)_position).get("HomeName").toString().concat(" X ".concat(high.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "high");
							startActivity(go);
									}
							});
					b3.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", high.get((int)_position).get("Hd3Link").toString());
							go.putExtra("MatchName", high.get((int)_position).get("HomeName").toString().concat(" X ".concat(high.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "high");
							startActivity(go);
									}
							});
					b4.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", high.get((int)_position).get("Hd4Link").toString());
							go.putExtra("MatchName", high.get((int)_position).get("HomeName").toString().concat(" X ".concat(high.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "high");
							startActivity(go);
									}
							});
					b5.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", high.get((int)_position).get("Hd5Link").toString());
							go.putExtra("MatchName", high.get((int)_position).get("HomeName").toString().concat(" X ".concat(high.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "high");
							startActivity(go);
									}
							});
					b6.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", high.get((int)_position).get("Hd6Link").toString());
							go.putExtra("MatchName", high.get((int)_position).get("HomeName").toString().concat(" X ".concat(high.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "high");
							startActivity(go);
									}
							});
				}
			});
			
			return _view;
		}
	}
	
	public class Today_listAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Today_listAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.live_and_upcoming, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout top = _view.findViewById(R.id.top);
			final LinearLayout topbg = _view.findViewById(R.id.topbg);
			final LinearLayout bottom = _view.findViewById(R.id.bottom);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout live = _view.findViewById(R.id.live);
			final TextView league = _view.findViewById(R.id.league);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final ImageView homeimg = _view.findViewById(R.id.homeimg);
			final TextView homename = _view.findViewById(R.id.homename);
			final LinearLayout timebg = _view.findViewById(R.id.timebg);
			final TextView time = _view.findViewById(R.id.time);
			final LinearLayout linear33 = _view.findViewById(R.id.linear33);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final ImageView awayimg = _view.findViewById(R.id.awayimg);
			final TextView awayname = _view.findViewById(R.id.awayname);
			final LinearLayout linear16 = _view.findViewById(R.id.linear16);
			final ImageView iconnn = _view.findViewById(R.id.iconnn);
			final TextView date = _view.findViewById(R.id.date);
			
			live.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFB71C1C));
			timebg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)3, 0xFFFFFFFF, Color.TRANSPARENT));
			_RoundCorner(20, 20, 0, 0, "#115c9f", top);
			_RoundCorner(0, 0, 20, 20, "#115c9f", bottom);
			league.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			homename.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			awayname.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			date.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			time.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			Glide.with(getApplicationContext()).load(Uri.parse(livet.get((int)_position).get("HomeImage").toString())).into(homeimg);
			Glide.with(getApplicationContext()).load(Uri.parse(livet.get((int)_position).get("AwayImage").toString())).into(awayimg);
			homename.setText(livet.get((int)_position).get("HomeName").toString());
			awayname.setText(livet.get((int)_position).get("AwayName").toString());
			league.setText(livet.get((int)_position).get("LeagueName").toString());
			time.setText(livet.get((int)_position).get("Time").toString());
			date.setText(livet.get((int)_position).get("Date").toString());
			if ("Upcoming".equals(livet.get((int)_position).get("LiveUpcoming").toString())) {
				live.setVisibility(View.GONE);
			}
			else {
				live.setVisibility(View.VISIBLE);
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final com.google.android.material.bottomsheet.BottomSheetDialog di = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
					View inflate = getLayoutInflater().inflate(R.layout.qui, null);
					di.setContentView(inflate);
					di.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
					LinearLayout l = (LinearLayout)
					inflate.findViewById(R.id.l);
					LinearLayout l1 = (LinearLayout)
					inflate.findViewById(R.id.l1);
					LinearLayout bbg1 = (LinearLayout)
					inflate.findViewById(R.id.bbg1);
					LinearLayout bbg2 = (LinearLayout)
					inflate.findViewById(R.id.bbg2);
					LinearLayout bbg3 = (LinearLayout)
					inflate.findViewById(R.id.bbg3);
					LinearLayout b1 = (LinearLayout)
					inflate.findViewById(R.id.b1);
					LinearLayout b2 = (LinearLayout)
					inflate.findViewById(R.id.b2);
					LinearLayout b3 = (LinearLayout)
					inflate.findViewById(R.id.b3);
					LinearLayout b4 = (LinearLayout)
					inflate.findViewById(R.id.b4);
					LinearLayout b5 = (LinearLayout)
					inflate.findViewById(R.id.b5);
					LinearLayout b6 = (LinearLayout)
					inflate.findViewById(R.id.b6);
					TextView t1 = (TextView)
					inflate.findViewById(R.id.t1);
					TextView t2 = (TextView)
					inflate.findViewById(R.id.t2);
					TextView t3 = (TextView)
					inflate.findViewById(R.id.t3);
					TextView t4 = (TextView)
					inflate.findViewById(R.id.t4);
					TextView t5 = (TextView)
					inflate.findViewById(R.id.t5);
					TextView t6 = (TextView)
					inflate.findViewById(R.id.t6);
					TextView t7 = (TextView)
					inflate.findViewById(R.id.t7);
					TextView t8 = (TextView)
					inflate.findViewById(R.id.t8);
					b1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					_RoundCorner(50, 50, 50, 50, "#ffffff", l);
					t1.setText(livet.get((int)_position).get("HomeName").toString().concat(" Vs ".concat(livet.get((int)_position).get("AwayName").toString())));
					if ("Live".equals(livet.get((int)_position).get("LiveUpcoming").toString())) {
						if ("0".equals(livet.get((int)_position).get("Hd1Link").toString())) {
							b1.setVisibility(View.GONE);
						}
						else {
							b1.setVisibility(View.VISIBLE);
							t3.setText(livet.get((int)_position).get("Hd1Name").toString());
						}
						if ("0".equals(livet.get((int)_position).get("Hd2Link").toString())) {
							b2.setVisibility(View.GONE);
						}
						else {
							b2.setVisibility(View.VISIBLE);
							t4.setText(livet.get((int)_position).get("Hd2Name").toString());
						}
						if ("0".equals(livet.get((int)_position).get("Hd3Link").toString())) {
							b3.setVisibility(View.GONE);
						}
						else {
							b3.setVisibility(View.VISIBLE);
							t5.setText(livet.get((int)_position).get("Hd3Name").toString());
						}
						if ("0".equals(livet.get((int)_position).get("Hd4Link").toString())) {
							b4.setVisibility(View.GONE);
						}
						else {
							b4.setVisibility(View.VISIBLE);
							t6.setText(livet.get((int)_position).get("Hd4Name").toString());
						}
						if ("0".equals(livet.get((int)_position).get("Hd5Link").toString())) {
							b5.setVisibility(View.GONE);
						}
						else {
							b5.setVisibility(View.VISIBLE);
							t7.setText(livet.get((int)_position).get("Hd5Name").toString());
						}
						if ("0".equals(livet.get((int)_position).get("Hd6Link").toString())) {
							b6.setVisibility(View.GONE);
						}
						else {
							b6.setVisibility(View.VISIBLE);
							t8.setText(livet.get((int)_position).get("Hd6Name").toString());
						}
						t2.setText("Check your internet status and select the quality");
					}
					else {
						b2.setVisibility(View.GONE);
						b1.setVisibility(View.GONE);
						b4.setVisibility(View.GONE);
						b3.setVisibility(View.GONE);
						b4.setVisibility(View.GONE);
						b5.setVisibility(View.GONE);
						b6.setVisibility(View.GONE);
						t2.setText("Live broadcast has not started yet");
					}
					di.show();
					b1.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", livet.get((int)_position).get("Hd1Link").toString());
							go.putExtra("MatchName", livet.get((int)_position).get("HomeName").toString().concat(" X ".concat(livet.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", livet.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b2.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", livet.get((int)_position).get("Hd2Link").toString());
							go.putExtra("MatchName", livet.get((int)_position).get("HomeName").toString().concat(" X ".concat(livet.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", livet.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b3.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", livet.get((int)_position).get("Hd3Link").toString());
							go.putExtra("MatchName", livet.get((int)_position).get("HomeName").toString().concat(" X ".concat(livet.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", livet.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b4.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", livet.get((int)_position).get("Hd4Link").toString());
							go.putExtra("MatchName", livet.get((int)_position).get("HomeName").toString().concat(" X ".concat(livet.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", livet.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b5.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", livet.get((int)_position).get("Hd5Link").toString());
							go.putExtra("MatchName", livet.get((int)_position).get("HomeName").toString().concat(" X ".concat(livet.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", livet.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b6.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", livet.get((int)_position).get("Hd6Link").toString());
							go.putExtra("MatchName", livet.get((int)_position).get("HomeName").toString().concat(" X ".concat(livet.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", livet.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
				}
			});
			
			return _view;
		}
	}
	
	public class HotAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public HotAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.live_and_upcoming, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout top = _view.findViewById(R.id.top);
			final LinearLayout topbg = _view.findViewById(R.id.topbg);
			final LinearLayout bottom = _view.findViewById(R.id.bottom);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout live = _view.findViewById(R.id.live);
			final TextView league = _view.findViewById(R.id.league);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final ImageView homeimg = _view.findViewById(R.id.homeimg);
			final TextView homename = _view.findViewById(R.id.homename);
			final LinearLayout timebg = _view.findViewById(R.id.timebg);
			final TextView time = _view.findViewById(R.id.time);
			final LinearLayout linear33 = _view.findViewById(R.id.linear33);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final ImageView awayimg = _view.findViewById(R.id.awayimg);
			final TextView awayname = _view.findViewById(R.id.awayname);
			final LinearLayout linear16 = _view.findViewById(R.id.linear16);
			final ImageView iconnn = _view.findViewById(R.id.iconnn);
			final TextView date = _view.findViewById(R.id.date);
			
			live.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFB71C1C));
			timebg.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)15, (int)3, 0xFFFFFFFF, Color.TRANSPARENT));
			_RoundCorner(20, 20, 0, 0, "#115c9f", top);
			_RoundCorner(0, 0, 20, 20, "#115c9f", bottom);
			league.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			homename.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			awayname.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			date.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			time.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/npp.ttf"), 1);
			Glide.with(getApplicationContext()).load(Uri.parse(hott.get((int)_position).get("HomeImage").toString())).into(homeimg);
			Glide.with(getApplicationContext()).load(Uri.parse(hott.get((int)_position).get("AwayImage").toString())).into(awayimg);
			homename.setText(hott.get((int)_position).get("HomeName").toString());
			awayname.setText(hott.get((int)_position).get("AwayName").toString());
			league.setText(hott.get((int)_position).get("LeagueName").toString());
			time.setText(hott.get((int)_position).get("Time").toString());
			date.setText(hott.get((int)_position).get("Date").toString());
			if ("Upcoming".equals(hott.get((int)_position).get("LiveUpcoming").toString())) {
				live.setVisibility(View.GONE);
			}
			else {
				live.setVisibility(View.VISIBLE);
			}
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					final com.google.android.material.bottomsheet.BottomSheetDialog di = new com.google.android.material.bottomsheet.BottomSheetDialog(HomeActivity.this);
					View inflate = getLayoutInflater().inflate(R.layout.qui, null);
					di.setContentView(inflate);
					di.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
					LinearLayout l = (LinearLayout)
					inflate.findViewById(R.id.l);
					LinearLayout l1 = (LinearLayout)
					inflate.findViewById(R.id.l1);
					LinearLayout bbg1 = (LinearLayout)
					inflate.findViewById(R.id.bbg1);
					LinearLayout bbg2 = (LinearLayout)
					inflate.findViewById(R.id.bbg2);
					LinearLayout bbg3 = (LinearLayout)
					inflate.findViewById(R.id.bbg3);
					LinearLayout b1 = (LinearLayout)
					inflate.findViewById(R.id.b1);
					LinearLayout b2 = (LinearLayout)
					inflate.findViewById(R.id.b2);
					LinearLayout b3 = (LinearLayout)
					inflate.findViewById(R.id.b3);
					LinearLayout b4 = (LinearLayout)
					inflate.findViewById(R.id.b4);
					LinearLayout b5 = (LinearLayout)
					inflate.findViewById(R.id.b5);
					LinearLayout b6 = (LinearLayout)
					inflate.findViewById(R.id.b6);
					TextView t1 = (TextView)
					inflate.findViewById(R.id.t1);
					TextView t2 = (TextView)
					inflate.findViewById(R.id.t2);
					TextView t3 = (TextView)
					inflate.findViewById(R.id.t3);
					TextView t4 = (TextView)
					inflate.findViewById(R.id.t4);
					TextView t5 = (TextView)
					inflate.findViewById(R.id.t5);
					TextView t6 = (TextView)
					inflate.findViewById(R.id.t6);
					TextView t7 = (TextView)
					inflate.findViewById(R.id.t7);
					TextView t8 = (TextView)
					inflate.findViewById(R.id.t8);
					b1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					b6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)10, 0xFF115C9F));
					_RoundCorner(50, 50, 50, 50, "#ffffff", l);
					t1.setText(hott.get((int)_position).get("HomeName").toString().concat(" Vs ".concat(hott.get((int)_position).get("AwayName").toString())));
					if ("Live".equals(hott.get((int)_position).get("LiveUpcoming").toString())) {
						if ("0".equals(hott.get((int)_position).get("Hd1Link").toString())) {
							b1.setVisibility(View.GONE);
						}
						else {
							b1.setVisibility(View.VISIBLE);
							t3.setText(hott.get((int)_position).get("Hd1Name").toString());
						}
						if ("0".equals(hott.get((int)_position).get("Hd2Link").toString())) {
							b2.setVisibility(View.GONE);
						}
						else {
							b2.setVisibility(View.VISIBLE);
							t4.setText(hott.get((int)_position).get("Hd2Name").toString());
						}
						if ("0".equals(hott.get((int)_position).get("Hd3Link").toString())) {
							b3.setVisibility(View.GONE);
						}
						else {
							b3.setVisibility(View.VISIBLE);
							t5.setText(hott.get((int)_position).get("Hd3Name").toString());
						}
						if ("0".equals(hott.get((int)_position).get("Hd4Link").toString())) {
							b4.setVisibility(View.GONE);
						}
						else {
							b4.setVisibility(View.VISIBLE);
							t6.setText(hott.get((int)_position).get("Hd4Name").toString());
						}
						if ("0".equals(hott.get((int)_position).get("Hd5Link").toString())) {
							b5.setVisibility(View.GONE);
						}
						else {
							b5.setVisibility(View.VISIBLE);
							t7.setText(hott.get((int)_position).get("Hd5Name").toString());
						}
						if ("0".equals(hott.get((int)_position).get("Hd6Link").toString())) {
							b6.setVisibility(View.GONE);
						}
						else {
							b6.setVisibility(View.VISIBLE);
							t8.setText(hott.get((int)_position).get("Hd6Name").toString());
						}
						t2.setText("Check your internet status and select the quality");
					}
					else {
						b2.setVisibility(View.GONE);
						b1.setVisibility(View.GONE);
						b4.setVisibility(View.GONE);
						b3.setVisibility(View.GONE);
						b4.setVisibility(View.GONE);
						b5.setVisibility(View.GONE);
						b6.setVisibility(View.GONE);
						t2.setText("Live broadcast has not started yet");
					}
					di.show();
					b1.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", hott.get((int)_position).get("Hd1Link").toString());
							go.putExtra("MatchName", hott.get((int)_position).get("HomeName").toString().concat(" X ".concat(hott.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", hott.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b2.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", hott.get((int)_position).get("Hd2Link").toString());
							go.putExtra("MatchName", hott.get((int)_position).get("HomeName").toString().concat(" X ".concat(hott.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", hott.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b3.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", hott.get((int)_position).get("Hd3Link").toString());
							go.putExtra("MatchName", hott.get((int)_position).get("HomeName").toString().concat(" X ".concat(hott.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", hott.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b4.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", hott.get((int)_position).get("Hd4Link").toString());
							go.putExtra("MatchName", hott.get((int)_position).get("HomeName").toString().concat(" X ".concat(hott.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", hott.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b5.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", hott.get((int)_position).get("Hd5Link").toString());
							go.putExtra("MatchName", hott.get((int)_position).get("HomeName").toString().concat(" X ".concat(hott.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", hott.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
					b6.setOnClickListener(new View.OnClickListener() {
									@Override
									public void onClick(View _view) {
											go.setClass(getApplicationContext(), LiveActivity.class);
							go.putExtra("PlayLink", hott.get((int)_position).get("Hd6Link").toString());
							go.putExtra("MatchName", hott.get((int)_position).get("HomeName").toString().concat(" X ".concat(hott.get((int)_position).get("AwayName").toString())));
							go.putExtra("id", "live");
							go.putExtra("lnoti", hott.get((int)_position).get("LiveNoti").toString());
							startActivity(go);
									}
							});
				}
			});
			
			return _view;
		}
	}
	
	public class All_news_listAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public All_news_listAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.news, null);
			}
			
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear25 = _view.findViewById(R.id.linear25);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final LinearLayout linear26 = _view.findViewById(R.id.linear26);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			
			Glide.with(getApplicationContext()).load(Uri.parse(news.get((int)_position).get("NewsImage").toString())).into(imageview1);
			textview1.setText(news.get((int)_position).get("NewsTitle").toString());
			textview3.setText(news.get((int)_position).get("Date").toString());
			textview4.setText(news.get((int)_position).get("NewsBy").toString());
			if (news.get((int)_position).get("NewsTitle").toString().length() > 90) {
				textview1.setText(news.get((int)_position).get("NewsTitle").toString().substring((int)(0), (int)(88)).concat("..."));
			}
			else {
				textview1.setText(news.get((int)_position).get("NewsTitle").toString());
			}
			linear3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					go.setClass(getApplicationContext(), NewsRedActivity.class);
					go.putExtra("Title", news.get((int)_position).get("NewsTitle").toString());
					go.putExtra("Date", textview3.getText().toString());
					go.putExtra("By", news.get((int)_position).get("NewsBy").toString());
					go.putExtra("News", news.get((int)_position).get("NewsAbout").toString());
					go.putExtra("Image1", news.get((int)_position).get("NewsImage").toString());
					go.putExtra("Image2", news.get((int)_position).get("NewsImage2").toString());
					go.putExtra("Image3", news.get((int)_position).get("NewsImage3").toString());
					startActivity(go);
				}
			});
			
			return _view;
		}
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.tvch, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			
			Glide.with(getApplicationContext()).load(Uri.parse(tvchmap.get((int)_position).get("image").toString())).into(imageview5);
			imageview5.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					go.setClass(getApplicationContext(), LiveActivity.class);
					go.putExtra("PlayLink", tvchmap.get((int)_position).get("link").toString());
					go.putExtra("MatchName", tvchmap.get((int)_position).get("channelName").toString());
					go.putExtra("id", "live");
					startActivity(go);
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}