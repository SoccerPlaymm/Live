package com.soccer.play;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import cn.jzvd.*;
import com.gdacciaro.iOSDialog.*;
import com.lxj.xpopup.*;
import com.startapp.sdk.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import java.util.concurrent.TimeUnit;
import com.startapp.sdk.ads.banner.*;
import com.startapp.sdk.adsbase.*;
import com.startapp.sdk.adsbase.adlisteners.*;

public class LiveActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String URL = "";
	private String url = "";
	private boolean open = false;
	private String playingstatus = "";
	private double oo9 = 0;
	private String ssssss = "";
	private String k5 = "";
	private String touching = "";
	private boolean fr = false;
	private boolean pr = false;
	private boolean rota = false;
	private double length = 0;
	private double sec = 0;
	private double min = 0;
	private double length2 = 0;
	private double sec2 = 0;
	private double min2 = 0;
	private double seek = 0;
	private double forwardskip = 0;
	private double backwordskip = 0;
	private double resumes = 0;
	private double zoom = 0;
	private double current = 0;
	private double cur = 0;
	private double mps = 0;
	private String type = "";
	private String srt = "";
	private String secs = "";
	private double con = 0;
	private double forwordskip = 0;
	private HashMap<String, Object> mapp = new HashMap<>();
	private String keyy = "";
	
	private ArrayList<String> fullitems = new ArrayList<>();
	private ArrayList<String> othermediainfolder = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> comen = new ArrayList<>();
	
	private LinearLayout bar;
	private LinearLayout linear7;
	private ImageView imageview3;
	private TextView tit;
	private RelativeLayout linear9;
	private LinearLayout linear3;
	private LinearLayout vidview;
	private LinearLayout controlss;
	private TextView zoomtype;
	private VideoView videoview1;
	private LinearLayout linear6;
	private LinearLayout linear12;
	private LinearLayout linear8;
	private LinearLayout linearcolor;
	private TextView love;
	private TextView cuple;
	private ImageView imageview13;
	private LinearLayout linear13;
	private LinearLayout skipprev;
	private LinearLayout linear14;
	private LinearLayout skipforw;
	private LinearLayout linear15;
	private ImageView rotate;
	private ProgressBar progressbar1;
	private ImageView pip;
	private ImageView playpause;
	private LinearLayout linear16;
	private ImageView hdr;
	private ImageView cast;
	private LinearLayout linear11;
	private ImageView zooom;
	private ImageView episodelist;
	private TextView textview2;
	private SeekBar seekbar1;
	private TextView textview3;
	private LinearLayout vandtext;
	private LinearLayout ads;
	private LinearLayout ads1;
	private LinearLayout ads2;
	private LinearLayout ads3;
	private TextView text;
	
	private TimerTask showtimer;
	private TimerTask prog;
	private TimerTask cooldown;
	private TimerTask timer;
	private TimerTask zooms;
	private Intent intent = new Intent();
	private SharedPreferences sp;
	private TimerTask load;
	private SharedPreferences Userr;
	private Calendar t = Calendar.getInstance();
	private RequestNetwork live;
	private RequestNetwork.RequestListener _live_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.live);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		bar = findViewById(R.id.bar);
		linear7 = findViewById(R.id.linear7);
		imageview3 = findViewById(R.id.imageview3);
		tit = findViewById(R.id.tit);
		linear9 = findViewById(R.id.linear9);
		linear3 = findViewById(R.id.linear3);
		vidview = findViewById(R.id.vidview);
		controlss = findViewById(R.id.controlss);
		zoomtype = findViewById(R.id.zoomtype);
		videoview1 = findViewById(R.id.videoview1);
		MediaController videoview1_controller = new MediaController(this);
		videoview1.setMediaController(videoview1_controller);
		linear6 = findViewById(R.id.linear6);
		linear12 = findViewById(R.id.linear12);
		linear8 = findViewById(R.id.linear8);
		linearcolor = findViewById(R.id.linearcolor);
		love = findViewById(R.id.love);
		cuple = findViewById(R.id.cuple);
		imageview13 = findViewById(R.id.imageview13);
		linear13 = findViewById(R.id.linear13);
		skipprev = findViewById(R.id.skipprev);
		linear14 = findViewById(R.id.linear14);
		skipforw = findViewById(R.id.skipforw);
		linear15 = findViewById(R.id.linear15);
		rotate = findViewById(R.id.rotate);
		progressbar1 = findViewById(R.id.progressbar1);
		pip = findViewById(R.id.pip);
		playpause = findViewById(R.id.playpause);
		linear16 = findViewById(R.id.linear16);
		hdr = findViewById(R.id.hdr);
		cast = findViewById(R.id.cast);
		linear11 = findViewById(R.id.linear11);
		zooom = findViewById(R.id.zooom);
		episodelist = findViewById(R.id.episodelist);
		textview2 = findViewById(R.id.textview2);
		seekbar1 = findViewById(R.id.seekbar1);
		textview3 = findViewById(R.id.textview3);
		vandtext = findViewById(R.id.vandtext);
		ads = findViewById(R.id.ads);
		ads1 = findViewById(R.id.ads1);
		ads2 = findViewById(R.id.ads2);
		ads3 = findViewById(R.id.ads3);
		text = findViewById(R.id.text);
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		Userr = getSharedPreferences("Userr", Activity.MODE_PRIVATE);
		live = new RequestNetwork(this);
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		videoview1.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
			@Override
			public void onPrepared(MediaPlayer _mediaPlayer) {
				getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
				pr = false;
				fr = false;
				seekbar1.setMax((int)videoview1.getDuration());
				length = videoview1.getDuration();
				long milliseconds = (int)length;
				 
				
				        // This method uses this formula :minutes =
				
				        // (milliseconds / 1000) / 60;
				
				        long minutes
				
				            = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
				 
				
				        // This method uses this formula seconds =
				
				        // (milliseconds / 1000);
				
				        long seconds
				
				            = (TimeUnit.MILLISECONDS.toSeconds(milliseconds)
				
				               % 60);
				
				String secondsStr = Long.toString(seconds);
				    String secs;
				    if (secondsStr.length() >= 2) {
					        secs = secondsStr.substring(0, 2);
					    } else {
					        secs = "0" + secondsStr;
					    }
				
				min = (int)minutes;
				textview3.setText(String.valueOf((long)(min)).concat(":".concat(secs)));
				prog = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								seekbar1.setProgress((int)videoview1.getCurrentPosition());
								length2 = videoview1.getCurrentPosition();
								long milliseconds = (int)length2;
								 
								
								        // This method uses this formula :minutes =
								
								        // (milliseconds / 1000) / 60;
								
								        long minutes
								
								            = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
								 
								
								        // This method uses this formula seconds =
								
								        // (milliseconds / 1000);
								
								        long seconds
								
								            = (TimeUnit.MILLISECONDS.toSeconds(milliseconds)
								
								               % 60);
								String secondsStr = Long.toString(seconds);
								    String secs;
								    if (secondsStr.length() >= 2) {
									        secs = secondsStr.substring(0, 2);
									    } else {
									        secs = "0" + secondsStr;
									    }
								
								min2 = (int)minutes;
								textview2.setText(String.valueOf((long)(min2)).concat(":".concat(secs)));
							}
						});
					}
				};
				_timer.scheduleAtFixedRate(prog, (int)(0), (int)(100));
				skipprev.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (pr) {
							backwordskip = length2 - 10000;
							videoview1.seekTo((int)backwordskip);
							cooldown = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											
										}
									});
								}
							};
							_timer.schedule(cooldown, (int)(1000));
						}
						else {
							pr = true;
							cooldown = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											pr = false;
										}
									});
								}
							};
							_timer.schedule(cooldown, (int)(500));
						}
					}
				});
				skipforw.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (fr) {
							forwordskip = length2 + 10000;
							videoview1.seekTo((int)forwordskip);
							cooldown = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											
										}
									});
								}
							};
							_timer.schedule(cooldown, (int)(1000));
						}
						else {
							fr = true;
							cooldown = new TimerTask() {
								@Override
								public void run() {
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											fr = false;
										}
									});
								}
							};
							_timer.schedule(cooldown, (int)(500));
						}
					}
				});
				playpause.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (videoview1.isPlaying()) {
							videoview1.pause();
							playpause.setImageResource(R.drawable.new_feed_play_icon);
							controlss.setVisibility(View.VISIBLE);
							open = false;
						}
						else {
							videoview1.start();
							playpause.setImageResource(R.drawable.new_feed_pause_icon);
							if (videoview1.isPlaying()) {
								showtimer = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												controlss.setVisibility(View.INVISIBLE);
												open = true;
											}
										});
									}
								};
								_timer.schedule(showtimer, (int)(5000));
							}
							else {
								controlss.setVisibility(View.VISIBLE);
								open = false;
							}
						}
					}
				});
				_loading();
			}
		});
		
		videoview1.setOnErrorListener(new MediaPlayer.OnErrorListener() {
			@Override
			public boolean onError(MediaPlayer _mediaPlayer, int _what, int _extra) {
				
				return true;
			}
		});
		
		videoview1.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
			@Override
			public void onCompletion(MediaPlayer _mediaPlayer) {
				
			}
		});
		
		episodelist.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (rota) {
					setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
					rota = false;
					
					// hide statusbar of Android
					// could also be done later
					getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
					        WindowManager.LayoutParams.FLAG_FULLSCREEN);
					_p(linear9, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) + 50, SketchwareUtil.getDisplayWidthPixels(getApplicationContext()));
					linear3.setVisibility(View.GONE);
					bar.setVisibility(View.GONE);
					episodelist.setImageResource(R.drawable.round_fullscreen_exit_white_36dp);
				}
				else {
					setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
					rota = true;
					_p(linear9, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()), 605);
					episodelist.setImageResource(R.drawable.round_fullscreen_white_36dp);
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
					if ("high".equals(getIntent().getStringExtra("id"))) {
						linear3.setVisibility(View.GONE);
						bar.setVisibility(View.GONE);
					}
					else {
						linear3.setVisibility(View.VISIBLE);
						bar.setVisibility(View.VISIBLE);
					}
				}
			}
		});
		
		seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				seek = _progressValue;
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				videoview1.seekTo((int)seek);
			}
		});
		
		_live_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		Window w = LiveActivity.this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor("#FFFFFF")); linearcolor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		LiveActivity.this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		zoom = 1;
		tit.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google.ttf"), 1);
		zoomtype.setVisibility(View.GONE);
		videoview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (open) {
					if (videoview1.isPlaying()) {
						controlss.setVisibility(View.INVISIBLE);
						open = false;
					}
					else {
						controlss.setVisibility(View.VISIBLE);
						open = true;
					}
				}
				else {
					controlss.setVisibility(View.VISIBLE);
					open = true;
					if (videoview1.isPlaying()) {
						showtimer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										controlss.setVisibility(View.INVISIBLE);
										open = false;
									}
								});
							}
						};
						_timer.schedule(showtimer, (int)(5000));
					}
					else {
						controlss.setVisibility(View.VISIBLE);
						open = true;
					}
				}
			}
		});
		url = getIntent().getStringExtra("player");
		videoview1.setMediaController(null);
		tit.setText(getIntent().getStringExtra("MatchName"));
		srt = "https://html5multimedia.com/code/ch8/elephants-dream-subtitles-en.vtt";
		videoview1.setVideoURI(Uri.parse(getIntent().getStringExtra("PlayLink")));
		videoview1.start();
		open = true;
		if (videoview1.isPlaying()) {
			showtimer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							controlss.setVisibility(View.INVISIBLE);
							open = false;
						}
					});
				}
			};
			_timer.schedule(showtimer, (int)(5000));
		}
		else {
			controlss.setVisibility(View.VISIBLE);
			open = true;
		}
		StartAppSDK.init(LiveActivity.this, "207297507", true);
		Banner banner1 = new Banner(LiveActivity.this);
		banner1.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		ads.addView(banner1);
		Banner banner2 = new Banner(LiveActivity.this);
		banner2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		ads1.addView(banner2);
		Banner banner3 = new Banner(LiveActivity.this);
		banner3.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		ads2.addView(banner3);
		Banner banner4 = new Banner(LiveActivity.this);
		banner4.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		ads3.addView(banner4);
		final StartAppAd int1 = new StartAppAd(LiveActivity.this);
		int1.showAd(new AdDisplayListener() {
				       @Override
				    public void adHidden(Ad ad) {
				
			}
				@Override
				    public void adDisplayed(Ad ad) {
						SketchwareUtil.showMessage(getApplicationContext(), "ad show");
						    }
				@Override
				    public void adClicked(Ad ad) {
						SketchwareUtil.showMessage(getApplicationContext(), "‌click");
						    }
				@Override
				    public void adNotDisplayed(Ad ad) {
						SketchwareUtil.showMessage(getApplicationContext(), "ad error");
						    }
		});
		StartAppAd.disableSplash();
		if ("high".equals(getIntent().getStringExtra("id"))) {
			setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
			rota = false;
			_p(linear9, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) + 50, SketchwareUtil.getDisplayWidthPixels(getApplicationContext()));
			linear3.setVisibility(View.GONE);
			bar.setVisibility(View.GONE);
			
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
			        WindowManager.LayoutParams.FLAG_FULLSCREEN);
			episodelist.setImageResource(R.drawable.round_fullscreen_exit_white_36dp);
			textview2.setVisibility(View.VISIBLE);
			seekbar1.setVisibility(View.VISIBLE);
			textview3.setVisibility(View.VISIBLE);
		}
		else {
			rota = true;
			linear3.setVisibility(View.VISIBLE);
			_p(linear9, SketchwareUtil.getDisplayWidthPixels(getApplicationContext()), 605);
			bar.setVisibility(View.VISIBLE);
			episodelist.setImageResource(R.drawable.round_fullscreen_white_36dp);
			textview2.setVisibility(View.GONE);
			seekbar1.setVisibility(View.GONE);
			textview3.setVisibility(View.GONE);
		}
		_Progress(progressbar1, "#b71c1c");
		seekbar1.getProgressDrawable().setColorFilter(Color.parseColor("#b71c1c"), PorterDuff.Mode.SRC_IN); seekbar1.getThumb().setColorFilter(Color.parseColor("#b71c1c"), PorterDuff.Mode.SRC_IN); 
		
		if ("high".equals(getIntent().getStringExtra("id"))) {
			
		}
		else {
			_MarqueeScrollTextView(text, getIntent().getStringExtra("lnoti"));
		}
	}
	
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
	}
	
	@Override
	public void onStop() {
		super.onStop();
		
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		
	}
	public void _p(final View _view, final double _width, final double _hight) {
		_view.setLayoutParams(new LinearLayout.LayoutParams((int)_width, (int)_hight));
	}
	
	
	public void _loading() {
		if (textview2.getText().toString().equals(textview3.getText().toString())) {
			
		}
		else {
			if (playingstatus.equals("")) {
				oo9 = 0;
				progressbar1.setVisibility(View.GONE);
				playpause.setVisibility(View.VISIBLE);
			}
			else {
				ssssss = love.getText().toString();
				load = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (love.getText().toString().equals(ssssss)) {
									oo9++;
									playpause.setVisibility(View.GONE);
									progressbar1.setVisibility(View.VISIBLE);
								}
								else {
									oo9 = 0;
									progressbar1.setVisibility(View.GONE);
									playpause.setVisibility(View.VISIBLE);
									showtimer = new TimerTask() {
										@Override
										public void run() {
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													if (k5.equals("")) {
														controlss.setVisibility(View.GONE);
														k5 = "pronto";
														touching = "";
													}
												}
											});
										}
									};
									_timer.schedule(showtimer, (int)(100));
								}
							}
						});
					}
				};
				_timer.schedule(load, (int)(5));
			}
		}
	}
	
	
	public void _play(final String _url) {
		url = getIntent().getStringExtra("player");
		videoview1.setMediaController(null);
		videoview1.setVideoURI(Uri.parse(getIntent().getStringExtra("player")));
		videoview1.start();
		open = true;
		showtimer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						controlss.setVisibility(View.INVISIBLE);
						open = false;
					}
				});
			}
		};
		_timer.schedule(showtimer, (int)(3000));
	}
	
	
	public void _MarqueeScrollTextView(final TextView _view, final String _text) {
		_view.setText(_text); _view.setSingleLine(true); _view.setEllipsize(TextUtils.TruncateAt.MARQUEE); _view.setSelected(true);
	}
	
	
	public void _SortMap(final ArrayList<HashMap<String, Object>> _listMap, final String _key, final boolean _isNumber, final boolean _Ascending) {
		Collections.sort(_listMap, new Comparator<HashMap<String,Object>>(){
			public int compare(HashMap<String,Object> _compareMap1, HashMap<String,Object> _compareMap2){
				if (_isNumber) {
					int _count1 = Integer.valueOf(_compareMap1.get(_key).toString());
					int _count2 = Integer.valueOf(_compareMap2.get(_key).toString());
					if (_Ascending) {
						return _count1 < _count2 ? -1 : _count1 < _count2 ? 1 : 0;
					}
					else {
						return _count1 > _count2 ? -1 : _count1 > _count2 ? 1 : 0;
					}
				}
				else {
					if (_Ascending) {
						return (_compareMap1.get(_key).toString()).compareTo(_compareMap2.get(_key).toString());
					}
					else {
						return (_compareMap2.get(_key).toString()).compareTo(_compareMap1.get(_key).toString());
					}
				}
			}});
	}
	
	
	public void _RoundCorner(final double _one, final double _two, final double _three, final double _four, final String _color, final View _view) {
		Double left_top = _one;
		Double right_top = _two;
		Double left_bottom = _three;
		Double right_bottom = _four;
		android.graphics.drawable.GradientDrawable c = new android.graphics.drawable.GradientDrawable();
		c.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
		c.setCornerRadii(new float[] {left_top.floatValue(),left_top.floatValue(), right_top.floatValue(),right_top.floatValue(), left_bottom.floatValue(),left_bottom.floatValue(), right_bottom.floatValue(),right_bottom.floatValue()});
		c.setColor(Color.parseColor(_color));
		_view.setBackground(c);
	}
	
	
	public void _Progress(final ProgressBar _progressbar, final String _color) {
		if (android.os.Build.VERSION.SDK_INT >= 21) {
			_progressbar.getIndeterminateDrawable().setColorFilter(Color.parseColor(_color), PorterDuff.Mode.SRC_IN);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}